
  # AI Exam Paper Generator

  This is a code bundle for AI Exam Paper Generator. The original project is available at https://www.figma.com/design/QyQDbMAHccu8hn8waWn8si/AI-Exam-Paper-Generator.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  